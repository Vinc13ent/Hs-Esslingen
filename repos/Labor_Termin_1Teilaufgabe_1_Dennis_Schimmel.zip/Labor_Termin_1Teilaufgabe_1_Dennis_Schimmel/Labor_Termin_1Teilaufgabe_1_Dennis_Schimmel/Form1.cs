﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Labor_Termin_1Teilaufgabe_1_Dennis_Schimmel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) //Verbinden
        {
            DemoDeviceTester demoDevice = new DemoDeviceTester();
            int value = (int)numericUpDown1.Value;
            demoDevice.Connect(value);
        }

        private void button2_Click(object sender, EventArgs e) // reset
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e) //
        {
            DemoDeviceTester demoDevice = new DemoDeviceTester();
            string temp = numericUpDown1.ToString();
            int PortNumber = Int32.Parse(temp);
            demoDevice.Connect(PortNumber);
        }

        private void button4_Click(object sender, EventArgs e) // +
        {

        }

        private void button3_Click(object sender, EventArgs e) // -
        {

        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e) //Verbindungs Status
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void ToolStrinpStatusLabel1_TextChan(object sender, EventArgs e)
        {

        }
    }
}
