﻿namespace Labor_Termin_1Teilaufgabe_1_Dennis_Schimmel
{
        public enum ConnectionState
        {
            connected,
            disconnected,
            connecting
        }    
    
}
