﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Threading;


namespace Labor_Termin_1Teilaufgabe_1_Dennis_Schimmel
{
    class DemoDeviceTester
    { 
        
        


        private enum ComandBytes : byte /*nicht ComandBytes schreiben (intern bedingt). Arduino abfrage befehle.*/
        {
            CounterToZero = 0x7A,
            DecrementCounter = 0x7B,
            IncrementCounter = 0x7C,
            SendDeviceCounter = 0x7D,
            SendDeviceNumber = 0x7E,
            SendDeviceName = 0x7F
        }
        public enum ConnectionStates
        {
            connected,
            disconnected,
            connecting
        }

        private ConnectionStates _ConnectionState;
        public ConnectionStates ConnenctionState  
        {
            set
            {
                _ConnectionState = value;
            }

            get
            {
                return _ConnectionState;
            }
        }

        private string _DeviceNumber;
        public string DeviceNumber //Propertie Serien Nummer ausgeben
        {
            get
            {
                return _DeviceNumber;
            }

            set
            {
                _DeviceNumber = value;
            }
        }

        private string _DeviceName;
        public string DeviceName //Propertie Name des Arduiono
        {
            get 
            {
                return _DeviceName;
            }

            set
            {
                _DeviceName = value;
            }
        }

        private int _CurrendNumber;
        public int CurrendNumber // Propertie Zähler(zahl) von Arduion
        {
            get
            {
                return _CurrendNumber;

                /*string zahl = ComandBytes.SendDeviceCounter.ToString();
                int _currentNumberToInt = Int32.Parse(zahl);
                return _currentNumberToInt;*/
            }  
            
            set
            {
                _CurrendNumber = value;
            }
        }

        SerialPort serialPort = new SerialPort();

        public void Connect(int portNumber)
        {
            
            serialPort.PortName = "com" + portNumber;
            serialPort.BaudRate = 9600;

            ConnectionState = ConnectionStates.connecting;

            try
            {
                serialPort.Open();
                ConnectionState = ConnectionState.connected;
                ReadDeviceInfo();
            }
            catch (IndexOutOfRangeException)
            {
                ConnectionState =  ConnectionState.disconnected;
            }


            finally
            {
                if (serialPort.IsOpen)
                {
                    ConnectionState = ConnectionState.connected;
                }
                else
                {
                    ConnectionState = ConnectionState.disconnected;
                }

                serialPort.Close();
            }

        }

        private void ReadDeviceInfo()
        {
            byte[] a = new byte[] { (byte)ComandBytes.SendDeviceName };
            serialPort.Write(a, 0, 1);

            DeviceName = serialPort.ReadLine();

            byte[] b = new byte[] { (byte)ComandBytes.SendDeviceCounter };
            serialPort.Write(b, 0, 1);

            DeviceNumber = serialPort.ReadLine();

            byte[] c = new byte[] { (byte)ComandBytes.SendDeviceNumber };
            serialPort.Write(c, 0, 1);

            DeviceNumber = Int16.Parse(serialPort.ReadLine());
            
        }

        public void Disconect()
        {
            serialPort.Close();
            ConnectionState = ConnectionStates.Disconnected;
        }

        public void Increment ()
        {
            byte[] d = new byte[] { (byte)ComandBytes.IncrementCounter };
            serialPort.Write(d, 0, 1);
        }
           
        public void Decrement()
        {
            byte[] e = new byte[] { (byte)ComandBytes.DecrementCounter };
            serialPort.Write(e, 0, 1);
        }

        public void Reset()
        {
            byte[] f = new byte[] { (byte)ComandBytes.CounterToZero};
            serialPort.Write(f, 0, 1);
        }
    }
}
